<!-- index.php -->
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'auth_check.php'; // Proteger todas las páginas que usen este header
//require_once 'header_nuevo.php'; // Conexión a la base de datos
require_once 'liquidaciones.php'; // Conexión a la base de datos
?>
