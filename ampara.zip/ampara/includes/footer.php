
    <!-- jQuery (necesario para DataTables) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables JS y dependencias Bootstrap 5 (si se sigue usando) -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <!-- Bootstrap CSS -->
    <!-- Bootstrap Bundle with Popper (Importante para Dropdowns y otros componentes BS) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
   
 
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <!-- Tus otros scripts si los tienes -->
    <!-- <script src="../scripts.js"></script> --> <!-- Ejemplo si tienes un scripts.js en la raíz -->
     <script src="../js/scripts.js"></script>
</body>
</html>