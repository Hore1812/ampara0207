<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Define BASE_URL: La aplicación está en la subcarpeta /ampara/
define('BASE_URL', '/ampara/');

require_once 'auth_check.php'; // Asumiendo que auth_check.php está en /ampara/includes/
require_once 'conexion.php';   // Asumiendo que conexion.php está en /ampara/includes/

// Variables para los datos del usuario
$nombre_usuario_display = 'Usuario';
$tipo_usuario_actual = null; 
$ruta_foto_usuario = BASE_URL . 'img/fotos/empleados/usuario01.png'; // Imagen por defecto con BASE_URL

if (isset($_SESSION['idusuario'])) {
    if (isset($_SESSION['nombre_usuario'])) {
        $nombre_usuario_display = htmlspecialchars($_SESSION['nombre_usuario']);
    }

    if (isset($_SESSION['idemp']) && isset($pdo)) { // Asegurarse que $pdo está disponible desde conexion.php
        try {
            $stmt_foto = $pdo->prepare("SELECT rutafoto FROM empleado WHERE idempleado = :idemp AND activo = 1");
            $stmt_foto->bindParam(':idemp', $_SESSION['idemp']);
            $stmt_foto->execute();
            $empleado_info = $stmt_foto->fetch(PDO::FETCH_ASSOC);
            if ($empleado_info && !empty($empleado_info['rutafoto'])) {
                $ruta_foto_usuario = BASE_URL . ltrim(htmlspecialchars($empleado_info['rutafoto']), '/');
            }
        } catch (PDOException $e) {
            error_log("Error al obtener rutafoto: " . $e->getMessage());
        }
    }

    if (isset($_SESSION['tipo_usuario'])) {
        $tipo_usuario_actual = $_SESSION['tipo_usuario'];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo BASE_URL; ?>img/favicon.png"/>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo BASE_URL; ?>img/favicon.png"/>
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo BASE_URL; ?>img/favicon.png"/>
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) : 'INTRANET-AMPARA'; ?></title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>css/estilo.css">
    <style>
        body { padding-top: 56px; }
        .user-avatar { width: 32px; height: 32px; object-fit: cover; }
        .main-content { padding-top: 1rem; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo BASE_URL; ?>index.php">
                <img src="<?php echo BASE_URL; ?>img/favicon.png" alt="Logo" style="height: 50px; margin-right: 10px;">
               AMPARA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavPrincipal" aria-controls="navbarNavPrincipal" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavPrincipal">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo BASE_URL; ?>index.php">Inicio</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownControl" role="button" data-bs-toggle="dropdown" aria-expanded="false">Control</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownControl">
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>control_registrar.php">Registrar</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>control_historico.php">Histórico</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownCalendario" role="button" data-bs-toggle="dropdown" aria-expanded="false">Calendario</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownCalendario">
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>calendario_personal.php">Personal</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>calendario_reuniones.php">Reuniones</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>calendario_normativas.php">Normativas</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownNoticias" role="button" data-bs-toggle="dropdown" aria-expanded="false">Noticias</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownNoticias">
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>noticias_horas.php">Horas</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>noticias_equipo.php">Equipo</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>noticias_noticias.php">Noticias</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>noticias_aprendizaje.php">Aprendizaje</a></li>
                        </ul>
                    </li>
                    <?php if ($tipo_usuario_actual == 1): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownAdministrativo" role="button" data-bs-toggle="dropdown" aria-expanded="false">Administrativo</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownAdministrativo">
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>admin/admin_reporte.php">Reporte</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>admin/admin_anuncios.php">Anuncios</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>admin/admin_usuarios.php">Usuarios</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>liquidaciones.php">Liquidaciones</a></li>
                        </ul>
                    </li>
                    <?php endif;?>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['idusuario'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="navbarDropdownUser" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="<?php echo $ruta_foto_usuario; ?>" alt="Foto de perfil" class="rounded-circle me-2 user-avatar" style="height: 50px; width: 50px;">
                                <?php echo $nombre_usuario_display; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownUser">
                                <li><a class="dropdown-item" href="#">Perfil</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>logout.php"><i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>login.php">Iniciar Sesión</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid main-content">
        <?php if (isset($_SESSION['mensaje_exito'])): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3">
                <?php echo htmlspecialchars($_SESSION['mensaje_exito']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['mensaje_exito']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['mensaje_error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-3">
                <?php echo htmlspecialchars($_SESSION['mensaje_error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['mensaje_error']); ?>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <!-- <script src="<?php echo BASE_URL; ?>js/scripts.js"></script> -->
</body>
</html>
