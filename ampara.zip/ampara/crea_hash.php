<?php
// crea_hash.php
echo "admin: " . password_hash("10286953", PASSWORD_DEFAULT) . "\n";
echo "editor: " . password_hash("password123", PASSWORD_DEFAULT) . "\n";
echo "consultor: " . password_hash("password123", PASSWORD_DEFAULT) . "\n";
echo "inactivo: " . password_hash("password123", PASSWORD_DEFAULT) . "\n";
?>